function __jsEvalReturn() {
    return {
        isVideoFormat: function (url) {
            return !0;
        },
    };
}
export { __jsEvalReturn };
